package com.tcs.lotr;

/**
 * Utility class used by script.
 */
public class SampleUtil {

    public static String getText() {
        return "Hello World.";
    }
}